from flask import Flask
from flask_cors import CORS

app = Flask(__name__)

CORS(app)
@app.route('/api/serverdetails',methods=['GET'])
def get_server_details():
    serverdetail = [
       {'serverid': 1,'servername':'SR001','location':'USA','serverstatus':'on'},
        {'serverid': 2,'servername':'SR002','location':'Australia','serverstatus':'off'},
         {'serverid': 3,'servername':'SR003','location':'England','serverstatus':'on'}

    ]
    return serverdetail;


if __name__  == '__main__':
    app.run()
