import React  from 'react';

const ServerDetails = ({serverdata}) => {

    return ( 
            <div>
                <table>
                    <thead>
                        <tr border="1" >
                            <td border="1">Server Id  </td>
                            <td border="1">Location  </td>
                            <td border="1">Server Name  </td>    
                            <td border="1">Server Status  </td>                        
                        </tr>
                    </thead>
                    <tbody>
                       {
                        serverdata.map((item => (
                            <tr border="1" key={item.serverid}>
                                 <td border="1">{item.serverid}</td>
                                <td border="1"> {item.location}</td>
                                <td border="1">{item.servername}</td>
                                <td border="1" >{item.serverstatus}</td>
                            </tr>
                        )))
                    }
                    </tbody>
                </table>
             </div>
    );
}

export default ServerDetails;