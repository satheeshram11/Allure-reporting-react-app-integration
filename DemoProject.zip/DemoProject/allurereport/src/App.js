import React  from 'react';
import logo from './logo.svg';
import { useState, useEffect } from 'react';
import './App.css';
import ServerDetails from './ServerDetails';
import useFetch from './useFetch';
import { render } from 'react-dom';

function App() {
 // const [changeload] = useState(true);
   //const [campanychange] = useState(null);
//  const [companydata] = useState(null);
 // useEffect(()=>{
   // fetch("http://api.zippopotam.us/us/98121").then(res=>{
     //return res.json();
    //}).then(result =>{
    //console.log(result)
  //  setTimeout(() => {
    //       campanychange(result);
      //      changeload(false);
        //  }, 3000);
   // })
   // },[])
  
  const{data : serverdata}=useFetch('http://127.0.0.1:5000/api/serverdetails');
  return (
    <div className="App">
      <header className="App-header">
        {console.log(serverdata)}
      {serverdata && <ServerDetails serverdata={serverdata}> </ServerDetails>} </header>
    </div>
  );
}

export default App;
